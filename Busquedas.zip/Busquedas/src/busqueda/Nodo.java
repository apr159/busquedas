/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busqueda;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Iterator;

/**
 *
 * @author Isma
 */
public class Nodo
{
   private Estado estado;
   private String accion;
   private int costoRuta;
   private Nodo padre;
   private int profundidad;

   //Declaración del estado
   public Nodo(Estado e)
   {  estado = e;
      accion = "";
      costoRuta = 0; 
      padre = null;
      profundidad = 0;
   }
   
   //Constructor

   public Nodo(EstadoVasosAgua estado, String accion, int costo,
      Nodo padre, int profundidad)
   {  
      this.estado = estado;
      this.accion = accion;
      this.costoRuta = padre.getCostoRuta() + costo; 
      this.padre = padre;
      this.profundidad = profundidad;
   }

   //Se crea una lista de tipo Nodop
   public List<Nodo> expander(Problema p)
   {  
      int profundidadHijo = profundidad+1;
      Iterator<EstadoSucesor> iter = p.funcionSucesor((EstadoVasosAgua) estado);
      List<Nodo> hijos = new ArrayList<Nodo>();
      while (iter.hasNext())
      {  
    	 EstadoSucesor succ =  iter.next();
     
         hijos.add(new Nodo((EstadoVasosAgua) succ.getEstado(), succ.getAccion(),
            succ.getCosto(), this, profundidadHijo));
      }
      return hijos;
   }

   public List<Nodo> getRutaDeRaiz()
   {  List<Nodo> ruta = new LinkedList<Nodo>();
      Nodo nodo = this;
      do
      {  ruta.add(0, nodo);
         nodo = nodo.padre;
      } while (nodo != null);
      return ruta;
   }

   public Estado getEstado(){  return estado;}
   public String getAccion(){  return accion;}
   public int getCostoRuta(){  return costoRuta;}
   public Nodo getPadre() {  return padre;}
   public int getProfundidad(){  return profundidad;}

}
