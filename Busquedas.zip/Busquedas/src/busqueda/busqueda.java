/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busqueda;

/**
 *
 * @author Isma
 */
public class busqueda {
    public static void main(String[] args) {		
		ProblemaVasosAgua pbm = new ProblemaVasosAgua();
                Busquedas bus = new Busquedas(pbm);
                bus.imprimir(bus.anchura());
	}
    
}
