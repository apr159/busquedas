/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busqueda;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author Isma
 */
public class ProblemaVasosAgua implements Problema{
    
    public boolean funcionObjetivo(Estado e) {
        EstadoVasosAgua est =(EstadoVasosAgua)e;
        if(est.vaso1==2 && est.vaso2==0){
			return true;
		}
		else{
			return false;
		}
    }
       
    public int getH(Estado e){
	return 0;
    }
    public Iterator<EstadoSucesor> funcionSucesor(Estado e){
	ArrayList<EstadoSucesor> sucesores = new ArrayList<EstadoSucesor>();
	EstadoVasosAgua estado = (EstadoVasosAgua)e;
	
	int aux=0;
	int temp=0;

	// LLenar el vaso 1
	if (estado.vaso1<4){
	sucesores.add(new EstadoSucesor(new EstadoVasosAgua(4,estado.vaso2),"Llenar vaso 1",1));
	}
	
	
	//Llenar el vaso 2 
	if(estado.vaso2<3){
		sucesores.add(new EstadoSucesor(new EstadoVasosAgua(estado.vaso1,3),"Lllenar vaso 2",1));
	}
		
	//Vaciar el vaso 1
		
	if(estado.vaso1>0){
        	sucesores.add(new EstadoSucesor(new EstadoVasosAgua(0,estado.vaso2),"Vaciar vaso 1",1));
	}
		
		
	//Vaciar el vaso 2
	if(estado.vaso2>0){
		sucesores.add(new EstadoSucesor(new EstadoVasosAgua(estado.vaso1,0),"vaciar vaso 2",1));
	
	}
		
	//Pasar el agua al vaso 2
		
	if(estado.vaso1>0 && estado.vaso2<3){
		
		aux= estado.vaso1 + estado.vaso2;			
		temp= aux-3;
		
			
		//Aux servirá para guardar la cantidad de litros que se le pasará a 2
		if(aux>3){
			aux=3;
		}
			
		sucesores.add(new EstadoSucesor(new EstadoVasosAgua(temp,aux),"Pasar agua del 1 al 2",1));
			
			
		
	}
		
		
	//Pasar agua al vaso 1
		
		
	if(estado.vaso1<4 && estado.vaso2>0){
		aux=estado.vaso1+ estado.vaso2;
		temp= aux-4;
			
			
		//Aux servirá para guardar la cantidad de litros que se le pasará a 1
		if(aux>4){
			aux=4;
		}
			
		sucesores.add(new EstadoSucesor(new EstadoVasosAgua(aux,temp),"Pasar agua del 2 al 1",1));
		
		
	}

	return sucesores.iterator();

    }
    public EstadoVasosAgua estadoInicial(){
	return new EstadoVasosAgua(4,3);
    }


    
    
}