/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busqueda;

/**
 *
 * @author Isma
 */
public class EstadoVasosAgua implements Estado {
    	int vaso1;
	int vaso2;

	public EstadoVasosAgua(int vaso1, int vaso2){
		this.vaso1 = vaso1;
		this.vaso2 = vaso2;
	}
    
}
