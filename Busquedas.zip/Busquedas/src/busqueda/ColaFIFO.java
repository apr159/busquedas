/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busqueda;
import java.util.LinkedList;
import java.util.Deque;

/**
 *
 * @author Isma
 */
public class ColaFIFO implements Cola  {
    Deque<Nodo> cola= new LinkedList();
    
    @Override
    public boolean estaVacia() {
        
        if(cola.size()==0){
            return true;
        }
        else{
            return false;
        }
        
        
    }

    @Override
    public void addNodo(Nodo nodo) {
        cola.addFirst(nodo);
    }

    @Override
    public Nodo removerNodoFrente() {
        return cola.removeLast(); 
        
    }

    @Override
    public int getTCola() {
        return cola.size();
        
    }
    
    
    
}
