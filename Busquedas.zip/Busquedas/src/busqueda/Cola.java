/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package busqueda;

/**
 *
 * @author Isma
 */
public interface Cola {
   public boolean estaVacia();
   public void addNodo(Nodo nodo);
   public Nodo removerNodoFrente();
   public int getTCola();
    
}
